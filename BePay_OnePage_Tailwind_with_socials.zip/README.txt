
BePay OnePage Tailwind static package (with social icon placeholders)
-------------------------------------------------------------------
Upload the folder contents to your cPanel public_html. The index files are in /en, /ru, /ka.
Tailwind loaded via CDN; custom CSS in /assets/css/style.css. Language JSONs in /assets/js/lang.
Enable SSL via cPanel (Let's Encrypt). Contact form uses mailto:info@bepay.ge.
